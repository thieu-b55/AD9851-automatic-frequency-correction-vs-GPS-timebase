/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/*
 * MIT license AD9851_frequency_control_GPS_timebase
 *
 *
 *
 *	Copyright 2023 thieu-b55
 *
 *  Permission is hereby granted, free of charge,
 *  to any person obtaining a copy of this software and associated documentation files (the “Software�?),
 *  to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED “AS IS�?, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 *  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define VOLGEND				GPIOB, GPIO_PIN_15
#define VORIG				GPIOA, GPIO_PIN_8
#define PLUS				GPIOB, GPIO_PIN_14
#define MIN					GPIOB, GPIO_PIN_13
#define OK					GPIOB, GPIO_PIN_12
#define PULSTELLER_ENABLE	GPIOA, GPIO_PIN_15
#define UNLOCKED			GPIOA, GPIO_PIN_10
#define LOCKED				GPIOA, GPIO_PIN_11
#define AD9851_FQ_UD		GPIOB, GPIO_PIN_9
#define AD9851_W_CLK		GPIOB, GPIO_PIN_8
#define AD9851_RESET		GPIOA, GPIO_PIN_6
#define AD9851_DATA			GPIOB, GPIO_PIN_7
/*
 * LCD functions >> https://embeddedthere.com/interfacing-stm32-with-i2c-lcd-with-hal-code-example/
 */
#define I2C_ADDR 			0x27
#define RS_BIT 				0
#define EN_BIT 				2
#define BL_BIT 				3
#define D4_BIT 				4
#define D5_BIT 				5
#define D6_BIT 				6
#define D7_BIT 				7
#define LCD_ROWS 			2
#define LCD_COLS 			16

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t buf[1];
volatile int toon_pulsen_bool = 0;
volatile int Hz = 0;
volatile int KHz = 0;
volatile int MHz = 0;
volatile uint32_t begin_tick_int;
volatile int verschil_tick_int;
int Hz_1 = 0;
int Hz_10 = 0;
int Hz_100 = 0;
int KHz_1 = 0;
int KHz_10 = 0;
int KHz_100 = 0;
int MHz_1 = 0;
int MHz_10 = 0;
int positie_teller_int = 1;
uint32_t keuzetijd_int;
int keuze_mogelijk_bool = 0;
unsigned long instelling;
unsigned long setpunt;
unsigned long AD9851_setting;
int gemeten_freq_int;
uint8_t commando;
uint32_t update_tick_int;
uint8_t w0 = 0x01;
uint8_t backlight_state = 1;
char lcd_tekst[15];

/* instellen Neo-M8 0.5Hz 50% duty bij locked en 1Hz 50% duty bij unlocked GPS */
int8_t M8N_init[] = {0xB5, 0x62, 0x06, 0x31, 0x20, 0x00, 0x00, 0x01, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00, 0x40, 0x42, 0x0f, 0x00, 0x80, 0x84,
		             0x1e, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x67, 0x00, 0x00, 0x00, 0xa4, 0x1e,
			         0xB5, 0x62, 0x06, 0x31, 0x01, 0x00, 0x00, 0x38, 0xE5};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
void toon_pulsen();
void kiezen_naar_instelling();
void instelling_naar_kiezen();
void toon_instelling();
void toon_instellen();
void AD9851_instellen();
/*
 * LCD functions >> https://embeddedthere.com/interfacing-stm32-with-i2c-lcd-with-hal-code-example/
 */
void lcd_write_nibble(uint8_t nibble, uint8_t rs);
void lcd_send_cmd(uint8_t cmd);
void lcd_send_data(uint8_t data);
void lcd_init();
void lcd_write_string(char *str);
void lcd_set_cursor(uint8_t row, uint8_t column);
void lcd_clear(void);
void lcd_backlight(uint8_t state);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  /* effe wachten (niet wissen) */
  HAL_Delay(2500);

  lcd_init();
  lcd_clear();
  lcd_set_cursor(0, 4);
  lcd_write_string("thieu-b55");
  lcd_set_cursor(1, 5);
  lcd_write_string("11/2023");
  HAL_Delay(4000);

  HAL_TIM_Base_Start_IT(&htim1);
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start_IT(&htim3);

  /* instellen NEO-M8 1Hz unlocked  0.5Hz locked   50% cycle */
  HAL_UART_Transmit(&huart1,(uint8_t *)M8N_init, sizeof(M8N_init), 100);

  /* RESET AD9851 */
  HAL_GPIO_WritePin(AD9851_DATA, RESET);
  HAL_GPIO_WritePin(AD9851_FQ_UD, RESET);
  HAL_GPIO_WritePin(AD9851_W_CLK, RESET);
  HAL_GPIO_WritePin(AD9851_RESET, RESET);
  HAL_GPIO_WritePin(AD9851_RESET, SET);
  HAL_GPIO_WritePin(AD9851_RESET, SET);
  HAL_GPIO_WritePin(AD9851_RESET, RESET);
  HAL_GPIO_WritePin(AD9851_W_CLK, SET);
  HAL_GPIO_WritePin(AD9851_W_CLK, SET);
  HAL_GPIO_WritePin(AD9851_W_CLK, RESET);
  HAL_GPIO_WritePin(AD9851_FQ_UD, SET);
  HAL_GPIO_WritePin(AD9851_FQ_UD, SET);
  HAL_GPIO_WritePin(AD9851_FQ_UD, RESET);

  /* instellen AD9851 10MHz */
  instelling = 10000000;
  instelling_naar_kiezen();
  toon_instelling();
  setpunt = instelling;
  AD9851_setting = ((instelling * 4294967296UL) / 180000000UL);
  AD9851_instellen();

  /* tijd tussen 2 pulsen >> gps locked unlocked */
  begin_tick_int = HAL_GetTick();
  update_tick_int = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(toon_pulsen_bool == 1){
		 toon_pulsen();
		 toon_pulsen_bool = 0;
	  }
	  if((keuze_mogelijk_bool == 0) && (HAL_GPIO_ReadPin(VOLGEND) || HAL_GPIO_ReadPin(VORIG) || HAL_GPIO_ReadPin(PLUS) || HAL_GPIO_ReadPin(MIN) || HAL_GPIO_ReadPin(OK))){
		  keuze_mogelijk_bool = 1;
		  keuzetijd_int = HAL_GetTick();
  		  instelling_naar_kiezen();
 		  toon_instellen();
		  HAL_Delay(250);
	  }
	  if((keuze_mogelijk_bool == 1) && ((HAL_GetTick() - keuzetijd_int) > 10000)){
		  keuze_mogelijk_bool = 0;
		  instelling_naar_kiezen();
		  toon_instelling();
	  }
	  if(keuze_mogelijk_bool == 1){
		  if(HAL_GPIO_ReadPin(VOLGEND)){
			  keuzetijd_int = HAL_GetTick();
			  positie_teller_int += 1;
			  if(positie_teller_int > 8){
				  positie_teller_int = 8;
			  }
			  toon_instellen();
			  HAL_Delay(250);
			  while(HAL_GPIO_ReadPin(VOLGEND)){
			  }
		  }
		  if(HAL_GPIO_ReadPin(VORIG)){
			  keuzetijd_int = HAL_GetTick();
			  positie_teller_int -= 1;
			  if(positie_teller_int < 1){
				  positie_teller_int = 1;
			  }
			  toon_instellen();
			  HAL_Delay(250);
			  while(HAL_GPIO_ReadPin(VORIG)){
			  }
		  }
		  if(HAL_GPIO_ReadPin(PLUS)){
			  keuzetijd_int = HAL_GetTick();
			  switch(positie_teller_int){
			  case 1:
				  Hz_1 += 1;
				  if(Hz_1 > 9){
					  Hz_1 = 0;
				  }
				  break;
			  case 2:
				  Hz_10 += 1;
				  if(Hz_10 > 9){
					  Hz_10 = 0;
				  }
				  break;
			  case 3:
				  Hz_100 += 1;
				  if(Hz_100 > 9){
					  Hz_100 = 0;
				  }
				  break;
			  case 4:
				  KHz_1 += 1;
				  if(KHz_1 > 9){
					  KHz_1 = 0;
				  }
				  break;
			  case 5:
				  KHz_10 += 1;
				  if(KHz_10 > 9){
					  KHz_10 = 0;
				  }
				  break;
			  case 6:
				  KHz_100 += 1;
				  if(KHz_100 > 9){
					  KHz_100 = 0;
				  }
				  break;
			  case 7:
				  MHz_1 += 1;
				  if(MHz_1 > 9){
						 MHz_1 = 0;
				  }
				  break;
			  case 8:
				  MHz_10 += 1;
				  if(MHz_10 > 2){
					 MHz_10 = 0;
				  }
			  }
			  toon_instellen();
			  HAL_Delay(250);
			  while(HAL_GPIO_ReadPin(PLUS)){
			  }
		  }
		  if(HAL_GPIO_ReadPin(MIN)){
			  keuzetijd_int = HAL_GetTick();
			  switch(positie_teller_int){
			  case 1:
				  Hz_1 -= 1;
				  if(Hz_1 < 0){
					  Hz_1 = 9;
				  }
				  break;
			  case 2:
				  Hz_10 -= 1;
				  if(Hz_10 < 0){
					  Hz_10 = 9;
				  }
				  break;
			  case 3:
				  Hz_100 -= 1;
				  if(Hz_100 < 0){
					  Hz_100 = 9;
				  }
				  break;
			  case 4:
				  KHz_1 -= 1;
				  if(KHz_1 < 0){
					  KHz_1 = 9;
				  }
				  break;
			  case 5:
				  KHz_10 -= 1;
				  if(KHz_10 < 0){
					  KHz_10 = 9;
				  }
				  break;
			  case 6:
				  KHz_100 -= 1;
				  if(KHz_100 < 0){
					  KHz_100 = 9;
				  }
				  break;
			  case 7:
				  MHz_1 -= 1;
				  if(MHz_1 < 0){
					  MHz_1 = 9;
				  }
				  break;
			  case 8:
				  MHz_10 -= 1;
				  if(MHz_10 < 0){
					  MHz_10 = 2;
				  }
			  }
			  toon_instellen();
			  HAL_Delay(250);
			  while(HAL_GPIO_ReadPin(MIN)){
			  }
		  }
		  if(HAL_GPIO_ReadPin(OK)){
			  kiezen_naar_instelling();
			  if(instelling > 25000000){
				  instelling = 25000000;
			  }
			  keuze_mogelijk_bool = 0;
			  instelling_naar_kiezen();
			  toon_instelling();
			  setpunt = instelling;
			  AD9851_setting = (instelling * 4294967296UL) / 180000000UL;
			  AD9851_instellen();
			  HAL_Delay(250);
			  while(HAL_GPIO_ReadPin(OK)){
			  }
		  }
	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void AD9851_instellen(){
	HAL_GPIO_WritePin(AD9851_W_CLK, RESET);
	HAL_GPIO_WritePin(AD9851_FQ_UD, RESET);
	for(int x = 0; x < 32; x++){
		HAL_GPIO_WritePin(AD9851_DATA, (AD9851_setting & 0x01));
		HAL_GPIO_WritePin(AD9851_W_CLK, SET);
		HAL_GPIO_WritePin(AD9851_W_CLK, RESET);
		AD9851_setting >>= 1;
	}
	commando = w0;
	for(int x = 0; x < 8; x++){
		HAL_GPIO_WritePin(AD9851_DATA, (commando & 0x01));
		commando >>= 1;
		HAL_GPIO_WritePin(AD9851_W_CLK, SET);
		HAL_GPIO_WritePin(AD9851_W_CLK, RESET);
	}
	HAL_GPIO_WritePin(AD9851_FQ_UD, SET);
	HAL_GPIO_WritePin(AD9851_FQ_UD, RESET);
}

void toon_instellen(){
	lcd_clear();
	lcd_set_cursor(1, 4);
	char buf[2];
	sprintf(buf, "%d", MHz_10);
	lcd_write_string(buf);
	sprintf(buf, "%d", MHz_1);
	lcd_write_string(buf);
	sprintf(buf, "%d", KHz_100);
	lcd_write_string(buf);
	sprintf(buf, "%d", KHz_10);
	lcd_write_string(buf);
	sprintf(buf, "%d", KHz_1);
	lcd_write_string(buf);
	sprintf(buf, "%d", Hz_100);
	lcd_write_string(buf);
	sprintf(buf, "%d", Hz_10);
	lcd_write_string(buf);
	sprintf(buf, "%d", Hz_1);
	lcd_write_string(buf);
	switch(positie_teller_int){
	case 1:
		lcd_set_cursor(0, 11);
		break;
	case 2:
		lcd_set_cursor(0, 10);
		break;
	case 3:
		lcd_set_cursor(0, 9);
		break;
	case 4:
		lcd_set_cursor(0, 8);
		break;
	case 5:
		lcd_set_cursor(0, 7);
		break;
	case 6:
		lcd_set_cursor(0, 6);
		break;
	case 7:
		lcd_set_cursor(0, 5);
		break;
	case 8:
		lcd_set_cursor(0, 4);
	}
	lcd_write_string("*");
}

void toon_instelling(){
	lcd_clear();
	int instelling_int = instelling;
	sprintf(lcd_tekst, "%08d", instelling_int);
	lcd_set_cursor(1, 0);
	lcd_write_string("S: ");
	lcd_write_string(lcd_tekst);
	memset(lcd_tekst, 0, sizeof(lcd_tekst));
}

void toon_pulsen(){
	if(verschil_tick_int < 1500){
		gemeten_freq_int = ((MHz * 1000000) + (KHz * 1000) + Hz) * 2;
		HAL_GPIO_WritePin(UNLOCKED, SET);
		HAL_GPIO_WritePin(LOCKED, RESET);
		MHz *= 2;
		KHz *= 2;
		if(KHz > 999){
			KHz -= 1000;
			MHz += 1;
		}
		Hz *= 2;
		if(Hz > 999){
			Hz -= 1000;
			KHz += 1;
		}
	}
	if(verschil_tick_int > 1499){
		gemeten_freq_int = (MHz * 1000000) + (KHz * 1000) + Hz;
		HAL_GPIO_WritePin(LOCKED, 1);
		HAL_GPIO_WritePin(UNLOCKED, 0);
	}
	if(keuze_mogelijk_bool == 0){
		lcd_set_cursor(0, 0);
		lcd_write_string("               ");
		sprintf(lcd_tekst, "%08d", gemeten_freq_int);
		lcd_set_cursor(0, 0);
		lcd_write_string("M: ");
		lcd_write_string(lcd_tekst);
		memset(lcd_tekst, 0, sizeof(lcd_tekst));
	}
	if((HAL_GetTick() - update_tick_int) > 2000){
    	update_tick_int = HAL_GetTick();
    	int setpunt_int = setpunt;
    	int instelling_int = instelling;
    	int temp_int;
    	temp_int = setpunt_int + ((instelling_int - gemeten_freq_int) / 2);
    	if(temp_int < 0){
    		setpunt = 0;
    	}
    	else{
    		setpunt = temp_int;
    	}
    	AD9851_setting = (setpunt * 4294967296UL) / 180000000UL;
    	AD9851_instellen();
    }
}

void kiezen_naar_instelling(){
	instelling = Hz_1 + (Hz_10 * 10) + (Hz_100 * 100) + (KHz_1 * 1000) + (KHz_10 * 10000) + (KHz_100 * 100000) + (MHz_1 * 1000000) + (MHz_10 *10000000);
}

void instelling_naar_kiezen(){
	MHz_10 = instelling / 10000000;
	MHz_1 = (instelling - (MHz_10 * 10000000)) / 1000000;
	KHz_100 = (instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000)) / 100000;
	KHz_10 = (instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000) - (KHz_100 * 100000)) / 10000;
	KHz_1 = (instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000) - (KHz_100 * 100000) - (KHz_10 * 10000)) / 1000;
	Hz_100 = (instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000) - (KHz_100 * 100000) - (KHz_10 * 10000) - (KHz_1 * 1000)) / 100;
	Hz_10 = (instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000) - (KHz_100 * 100000) - (KHz_10 * 10000) - (KHz_1 * 1000) - (Hz_100 * 100)) / 10;
	Hz_1 = instelling - (MHz_10 * 10000000) - (MHz_1 * 1000000) - (KHz_100 * 100000) - (KHz_10 * 10000) - (KHz_1 * 1000) - (Hz_100 * 100) - (Hz_10 * 10);
}

/*
 * LCD functions >> https://embeddedthere.com/interfacing-stm32-with-i2c-lcd-with-hal-code-example/
 */
void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
  uint8_t data = nibble << D4_BIT;
  data |= rs << RS_BIT;
  data |= backlight_state << BL_BIT; // Include backlight state in data
  data |= 1 << EN_BIT;
  HAL_I2C_Master_Transmit(&hi2c2, I2C_ADDR << 1, &data, 1, 100);
  HAL_Delay(1);
  data &= ~(1 << EN_BIT);
  HAL_I2C_Master_Transmit(&hi2c2, I2C_ADDR << 1, &data, 1, 100);
}

void lcd_send_cmd(uint8_t cmd) {
  uint8_t upper_nibble = cmd >> 4;
  uint8_t lower_nibble = cmd & 0x0F;
  lcd_write_nibble(upper_nibble, 0);
  lcd_write_nibble(lower_nibble, 0);
  if (cmd == 0x01 || cmd == 0x02) {
    HAL_Delay(2);
  }
}

void lcd_send_data(uint8_t data) {
  uint8_t upper_nibble = data >> 4;
  uint8_t lower_nibble = data & 0x0F;
  lcd_write_nibble(upper_nibble, 1);
  lcd_write_nibble(lower_nibble, 1);
}

void lcd_init() {
  HAL_Delay(50);
  lcd_write_nibble(0x03, 0);
  HAL_Delay(5);
  lcd_write_nibble(0x03, 0);
  HAL_Delay(1);
  lcd_write_nibble(0x03, 0);
  HAL_Delay(1);
  lcd_write_nibble(0x02, 0);
  lcd_send_cmd(0x28);
  lcd_send_cmd(0x0C);
  lcd_send_cmd(0x06);
  lcd_send_cmd(0x01);
  HAL_Delay(2);
}

void lcd_write_string(char *str) {
  while (*str) {
    lcd_send_data(*str++);
  }
}

void lcd_set_cursor(uint8_t row, uint8_t column) {
    uint8_t address;
    switch (row) {
        case 0:
            address = 0x00;
            break;
        case 1:
            address = 0x40;
            break;
        default:
            address = 0x00;
    }
    address += column;
    lcd_send_cmd(0x80 | address);
}

void lcd_clear(void) {
	lcd_send_cmd(0x01);
    HAL_Delay(2);
}

void lcd_backlight(uint8_t state) {
  if (state) {
    backlight_state = 1;
  } else {
    backlight_state = 0;
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
